# Script FullComputerInfo.ps1
# Objetivo: Crear un informe con informaci�n b�sica del ordenador.

# Guardamos el nombre del equipo
$computerName = $env:COMPUTERNAME

# Indicamos el directorio y nombre del archivo que vamos a crear
$directorio = "C:\Temp"
$nombreFichero = "${computerName}_Info.txt"
$rutaCompletaFichero = Join-Path -Path $directorio -ChildPath $nombreFichero

# Si el directorio C:\Temp no existe, salimos
if (-not (Test-Path -Path $directorio -PathType Container)) {
    Write-Host "ERROR: El directorio $directorio no existe. Abortando ejecuci�n."
    exit
}

# Si el archivo ya existe, no seguimos
if (Test-Path -Path $rutaCompletaFichero -PathType Leaf) {
    Write-Host "ERROR: Ya existe un fichero llamado '$nombreFichero'. Abortando ejecuci�n."
    exit
}

# Obtenemos informaci�n general del equipo y del sistema operativo
$computerInfo = Get-CimInstance -ClassName Win32_ComputerSystem
$osInfo = Get-CimInstance -ClassName Win32_OperatingSystem

# Tratamos de convertir la fecha de instalaci�n a un formato legible
try {
    if ($osInfo.InstallDate -and $osInfo.InstallDate.Length -gt 0) {
        $fechaInstalacion = [Management.ManagementDateTimeConverter]::ToDateTime($osInfo.InstallDate)
        $fechaInstalacionTexto = $fechaInstalacion.ToString("yyyy-MM-dd HH:mm:ss")
    } else {
        $fechaInstalacionTexto = "No disponible"
    }
} catch {
    $fechaInstalacionTexto = "No disponible"
}

# Indicamos el tipo de producto de Windows (ej: Workstation, Server...)
$productTypeMap = @{1 = "Workstation"; 2 = "Domain Controller"; 3 = "Server"}
$productTypeStr = $productTypeMap[[int]$osInfo.ProductType]
if (-not $productTypeStr) { $productTypeStr = "Desconocido ($($osInfo.ProductType))" }

# Obtenemos la lista de discos f�sicos
$discos = Get-CimInstance -ClassName Win32_DiskDrive
$numDiscos = if ($discos) { @($discos).Count } else { 0 }

# Obtenemos los vol�menes (particiones con letra, como C:, D:, etc.)
$volumes = Get-CimInstance -ClassName Win32_Volume | Where-Object { $_.DriveLetter -ne $null }
$numVolumes = if ($volumes) { @($volumes).Count } else { 0 }

# Convertimos el tipo de unidad a palabras (por ejemplo, "Local" o "CD-ROM")
$driveTypeMap = @{
    0 = "Desconocido"
    1 = "Sin ra�z"
    2 = "Removible"
    3 = "Local"
    4 = "Red"
    5 = "CD-ROM"
    6 = "RAM Disk"
}

# Empezamos a construir el contenido del informe
$contenidoInforme = @()

# Secci�n: Informaci�n b�sica del equipo
$contenidoInforme += "------------------------------ Identificaci�n del equipo ------------------------------"
$contenidoInforme += "Nombre equipo: $($computerInfo.Name)"
$contenidoInforme += "Dominio: $($computerInfo.Domain)"
$contenidoInforme += ""

# Secci�n: Informaci�n del sistema operativo
$contenidoInforme += "------------------------------ Informaci�n del sistema operativo ------------------------------"
$contenidoInforme += "Edici�n de Windows: $($osInfo.Caption)"
$contenidoInforme += "Fecha de instalaci�n: $fechaInstalacionTexto"
$contenidoInforme += "Directorio de Windows: $($osInfo.WindowsDirectory)"
$contenidoInforme += "Arquitectura del SO: $($osInfo.OSArchitecture)"
$contenidoInforme += "Tipo de producto: $productTypeStr [Expresado en palabras]"
$contenidoInforme += ""

# Secci�n: Lista de discos f�sicos
$contenidoInforme += "------------------------------ Listado de discos ------------------------------"
$contenidoInforme += "N� de discos: $numDiscos"
$discosArray = @($discos)
for ($i = 0; $i -lt $discosArray.Count; $i++) {
    $d = $discosArray[$i]
    $contenidoInforme += ""
    $contenidoInforme += "============= Disco $i ============"
    $contenidoInforme += "Nombre: $($d.DeviceID)"
    $contenidoInforme += "Modelo: $($d.Model)"
    $contenidoInforme += ("Tama�o (en GB): {0:N2}" -f ($d.Size / 1GB))
}

# Secci�n: Lista de vol�menes (particiones)
$contenidoInforme += ""
$contenidoInforme += "------------------------------ Listado de vol�menes ------------------------------"
$contenidoInforme += "N� de vol�menes: $numVolumes"
$volumesArray = @($volumes)
for ($i = 0; $i -lt $volumesArray.Count; $i++) {
    $v = $volumesArray[$i]
    $tipoDrive = $driveTypeMap[[int]$v.DriveType]
    if (-not $tipoDrive) { $tipoDrive = "Desconocido ($($v.DriveType))" }

    $contenidoInforme += ""
    $contenidoInforme += "============= Volumen $i ============"
    $contenidoInforme += "Letra asignada: $($v.DriveLetter)"
    $contenidoInforme += ("Capacidad (en MB): {0:N2}" -f ($v.Capacity / 1MB))
    $contenidoInforme += ("Espacio libre (en MB): {0:N2}" -f ($v.FreeSpace / 1MB))
    $contenidoInforme += "Tipo de drive: $tipoDrive [Expresado en palabras]"
    $contenidoInforme += "Sistema de ficheros: $($v.FileSystem)"
}

# Guardamos el contenido del informe en un archivo de texto
$contenidoInforme | Out-File -FilePath $rutaCompletaFichero -Encoding Default

# Avisamos que todo fue bien
Write-Host "Se ha creado con �xito el fichero informativo '$rutaCompletaFichero'."