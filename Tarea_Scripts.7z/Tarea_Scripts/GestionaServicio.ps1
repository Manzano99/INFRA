# Script GestionaServicio.ps1
# Objetivo: Obtener información de un servicio de Windows local usando WMI. [cite: 37, 39]

# Solicitar el nombre del servicio al usuario [cite: 40]
$nombreServicio = Read-Host "Introduce el nombre del servicio a consultar"

# Validar que se introdujo un nombre
if ([string]::IsNullOrWhiteSpace($nombreServicio)) {
    Write-Host "Nombre de servicio no válido."
    exit
}

# Consultar el servicio usando Get-CimInstance con -query (obligatorio) [cite: 47, 38]
# Escapar caracteres especiales en el nombre si es necesario para la query WQL
$nombreServicioEscapado = $nombreServicio -replace "'", "''"
$query = "SELECT * FROM Win32_Service WHERE Name = '$nombreServicioEscapado'"

try {
    $servicio = Get-CimInstance -Query $query -ErrorAction Stop
} catch [Microsoft.Management.Infrastructure.CimException] {
    # Capturar excepción específica si Get-CimInstance no encuentra nada
    Write-Host "ERROR: No se encontró ningún servicio con el nombre '$nombreServicio'." [cite: 42]
    exit
} catch {
    # Otras posibles excepciones
    Write-Host "ERROR: Ocurrió un error inesperado al buscar el servicio '$nombreServicio'."
    Write-Host $_.Exception.Message
    exit
}

# Si $servicio existe (se encontró), mostrar menú [cite: 43]
Write-Host "`n--- Información disponible para el servicio '$($servicio.Name)' ---"
Write-Host "1) Descripción del cometido"
Write-Host "2) Modo de arranque (StartMode)"
Write-Host "3) Estado actual (State)"
Write-Host "4) Ruta del ejecutable (PathName)"
Write-Host "5) Nombre largo (Caption)"
Write-Host "--------------------------------------------------"

# Solicitar opción al usuario [cite: 44]
$opcion = Read-Host "Introduce el número de la opción deseada (1-5)"

# Procesar la opción [cite: 45, 46]
switch ($opcion) {
    '1' { Write-Host "Descripción : $($servicio.Description)" }
    '2' { Write-Host "Modo de arranque: $($servicio.StartMode)" }
    '3' { Write-Host "Estado        : $($servicio.State)" }
    '4' { Write-Host "Ruta          : $($servicio.PathName)" }
    '5' { Write-Host "Nombre largo  : $($servicio.Caption)" }
    default {
        # Opción inválida [cite: 45]
        Write-Host "Opción inválida. Debes introducir un número entre 1 y 5."
    }
}

# El script termina tras mostrar la información o el error de opción inválida [cite: 45]
Write-Host "`nScript finalizado."
