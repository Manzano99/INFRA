# Script HandleInfo.ps1
# Objetivo: Crear un fichero informativo sobre la utilización de handles por procesos.

# Solicitar el nombre del fichero al usuario
$nombreFichero = Read-Host "Introduce el nombre para el fichero informativo (ej: handles_report.txt)"
if (-not $nombreFichero) {
    Write-Host "Nombre de fichero inválido."
    exit
}

# Definir el directorio y la ruta completa del fichero
$directorio = "C:\Temp"
$rutaCompletaFichero = Join-Path -Path $directorio -ChildPath $nombreFichero

# Comprobar si existe el directorio C:\Temp
if (-not (Test-Path -Path $directorio -PathType Container)) {
    Write-Host "ERROR: El directorio $directorio no existe. Abortando ejecución."
    exit
}

# Obtener los procesos y ordenarlos por HandleCount
$procesos = Get-Process | Sort-Object HandleCount

# Definir la cabecera
$cabecera = "{0,-10} {1,-30} {2,20}" -f "Id", "Nombre", "Número de handles"
$lineaSeparadora = "=" * ($cabecera.Length)

# Crear/Sobrescribir el fichero y escribir la cabecera
Out-File -FilePath $rutaCompletaFichero -Encoding Default -InputObject $lineaSeparadora
Add-Content -Path $rutaCompletaFichero -Encoding Default -Value $cabecera
Add-Content -Path $rutaCompletaFichero -Encoding Default -Value $lineaSeparadora

# Tramo 1: 0-100 handles
Add-Content -Path $rutaCompletaFichero -Encoding Default -Value "`n######### Procesos entre 0 y 100 handles #########`n"
Add-Content -Path $rutaCompletaFichero -Encoding Default -Value $cabecera
Add-Content -Path $rutaCompletaFichero -Encoding Default -Value $lineaSeparadora

foreach ($p in $procesos) {
    if ($p.HandleCount -ge 0 -and $p.HandleCount -le 100) {
        $linea = "{0,-10} {1,-30} {2,20}" -f $p.Id, $p.ProcessName, $p.HandleCount
        Add-Content -Path $rutaCompletaFichero -Encoding Default -Value $linea
    }
}

# Tramo 2: 101-1000 handles
Add-Content -Path $rutaCompletaFichero -Encoding Default -Value "`n####### Procesos entre 101 y 1000 handles ########`n"
Add-Content -Path $rutaCompletaFichero -Encoding Default -Value $cabecera
Add-Content -Path $rutaCompletaFichero -Encoding Default -Value $lineaSeparadora

foreach ($p in $procesos) {
    if ($p.HandleCount -ge 101 -and $p.HandleCount -le 1000) {
        $linea = "{0,-10} {1,-30} {2,20}" -f $p.Id, $p.ProcessName, $p.HandleCount
        Add-Content -Path $rutaCompletaFichero -Encoding Default -Value $linea
    }
}

# Tramo 3: >1000 handles
Add-Content -Path $rutaCompletaFichero -Encoding Default -Value "`n######## Procesos con más de 1000 handles ########`n"
Add-Content -Path $rutaCompletaFichero -Encoding Default -Value $cabecera
Add-Content -Path $rutaCompletaFichero -Encoding Default -Value $lineaSeparadora

foreach ($p in $procesos) {
    if ($p.HandleCount -gt 1000) {
        $linea = "{0,-10} {1,-30} {2,20}" -f $p.Id, $p.ProcessName, $p.HandleCount
        Add-Content -Path $rutaCompletaFichero -Encoding Default -Value $linea
    }
}

Write-Host "Fichero informativo '$rutaCompletaFichero' generado con éxito."